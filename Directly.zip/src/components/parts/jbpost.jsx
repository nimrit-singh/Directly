import React from "react";
const jbpost = ()=>{
    return(
        <>
        
        </>
    )
}