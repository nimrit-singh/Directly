import React from "react";
const Malert=(props)=>{
<>
<div className="malert">
    {props.children}
</div>
</>
}
export default Malert