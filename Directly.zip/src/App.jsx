import React from 'react';
// import './assets/style/App.css';
import AllRoutes from './components/routes/AllRoutes';

function App() {
  return (
  
<><AllRoutes/></>
  )
}



export default App
